#!/bin/bash

# HIKLASS TASK MASTER - Build Script
# This script builds the signed APK and AAB for Play Store upload

echo "═══════════════════════════════════════════════════════════════"
echo "          HIKLASS TASK MASTER - Build Script"
echo "═══════════════════════════════════════════════════════════════"
echo ""

# Check if Android SDK is set
if [ -z "$ANDROID_SDK_ROOT" ] && [ -z "$ANDROID_HOME" ]; then
    echo "⚠️  Warning: ANDROID_SDK_ROOT or ANDROID_HOME not set"
    echo "Please set your Android SDK path before running this script"
    exit 1
fi

# Clean previous builds
echo "🧹 Cleaning previous builds..."
./gradlew clean

# Build signed APK
echo ""
echo "📦 Building signed APK..."
./gradlew assembleRelease

# Build signed AAB (for Play Store)
echo ""
echo "📦 Building signed AAB (Play Store Bundle)..."
./gradlew bundleRelease

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "                      BUILD COMPLETE"
echo "═══════════════════════════════════════════════════════════════"
echo ""
echo "📱 Signed APK:"
echo "   app/build/outputs/apk/release/app-release.apk"
echo ""
echo "📦 Play Store Bundle (AAB):"
echo "   app/build/outputs/bundle/release/app-release.aab"
echo ""
echo "🚀 Ready for Play Store upload!"
echo ""

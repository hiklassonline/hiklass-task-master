package com.hiklass.taskmaster.ui.main

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupMenu
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.hiklass.taskmaster.R
import com.hiklass.taskmaster.data.model.Task
import com.hiklass.taskmaster.data.model.TaskStatus
import com.hiklass.taskmaster.data.model.getColorRes
import com.hiklass.taskmaster.data.model.getDisplayName
import com.hiklass.taskmaster.databinding.ItemTaskBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class TaskAdapter(
    private val onTaskClick: (Task) -> Unit,
    private val onTaskComplete: (Task) -> Unit,
    private val onTaskDelete: (Task) -> Unit,
    private val onTaskEdit: (Task) -> Unit
) : ListAdapter<Task, TaskAdapter.TaskViewHolder>(TaskDiffCallback()) {
    
    private val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
    private val dateTimeFormat = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val binding = ItemTaskBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return TaskViewHolder(binding)
    }
    
    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        holder.bind(getItem(position))
    }
    
    inner class TaskViewHolder(
        private val binding: ItemTaskBinding
    ) : RecyclerView.ViewHolder(binding.root) {
        
        fun bind(task: Task) {
            binding.apply {
                // Title
                tvTaskTitle.text = task.title
                
                // Description (show if not empty)
                tvTaskDescription.apply {
                    text = task.description
                    visibility = if (task.description.isNotBlank()) View.VISIBLE else View.GONE
                }
                
                // Priority badge
                tvPriority.apply {
                    text = task.priority.getDisplayName()
                    setBackgroundColor(
                        ContextCompat.getColor(context, task.priority.getColorRes())
                    )
                }
                
                // Status badge
                tvStatus.apply {
                    text = task.status.getDisplayName()
                    setTextColor(ContextCompat.getColor(context, task.status.getColorRes()))
                }
                
                // Deadline
                task.deadline?.let { deadline ->
                    tvDeadline.visibility = View.VISIBLE
                    tvDeadline.text = formatDeadline(deadline)
                    
                    // Set color based on urgency
                    val daysUntil = getDaysUntil(deadline)
                    when {
                        daysUntil < 0 -> {
                            tvDeadline.setTextColor(ContextCompat.getColor(root.context, R.color.deadline_overdue))
                        }
                        daysUntil <= 1 -> {
                            tvDeadline.setTextColor(ContextCompat.getColor(root.context, R.color.deadline_urgent))
                        }
                        daysUntil <= 2 -> {
                            tvDeadline.setTextColor(ContextCompat.getColor(root.context, R.color.deadline_soon))
                        }
                        else -> {
                            tvDeadline.setTextColor(ContextCompat.getColor(root.context, R.color.deadline_normal))
                        }
                    }
                } ?: run {
                    tvDeadline.visibility = View.GONE
                }
                
                // Sync status indicator
                ivSyncStatus.visibility = if (task.isSynced) View.GONE else View.VISIBLE
                
                // Complete checkbox
                cbComplete.apply {
                    isChecked = task.status == TaskStatus.COMPLETED
                    setOnClickListener {
                        if (task.status != TaskStatus.COMPLETED) {
                            onTaskComplete(task)
                        }
                    }
                }
                
                // Click listeners
                root.setOnClickListener { onTaskClick(task) }
                
                btnMore.setOnClickListener { view ->
                    showPopupMenu(view, task)
                }
                
                // Dim completed tasks
                root.alpha = if (task.status == TaskStatus.COMPLETED) 0.6f else 1.0f
            }
        }
        
        private fun formatDeadline(deadline: Date): String {
            val daysUntil = getDaysUntil(deadline)
            val dateStr = dateFormat.format(deadline)
            
            return when {
                daysUntil < 0 -> "Overdue: $dateStr"
                daysUntil == 0L -> "Today: $dateStr"
                daysUntil == 1L -> "Tomorrow: $dateStr"
                else -> "Due: $dateStr"
            }
        }
        
        private fun getDaysUntil(deadline: Date): Long {
            val now = Date()
            val diff = deadline.time - now.time
            return TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS)
        }
        
        private fun showPopupMenu(view: View, task: Task) {
            PopupMenu(view.context, view).apply {
                menuInflater.inflate(R.menu.menu_task_item, menu)
                
                setOnMenuItemClickListener { item ->
                    when (item.itemId) {
                        R.id.action_edit -> {
                            onTaskEdit(task)
                            true
                        }
                        R.id.action_delete -> {
                            onTaskDelete(task)
                            true
                        }
                        R.id.action_complete -> {
                            onTaskComplete(task)
                            true
                        }
                        else -> false
                    }
                }
                
                show()
            }
        }
    }
    
    class TaskDiffCallback : DiffUtil.ItemCallback<Task>() {
        override fun areItemsTheSame(oldItem: Task, newItem: Task): Boolean {
            return oldItem.id == newItem.id
        }
        
        override fun areContentsTheSame(oldItem: Task, newItem: Task): Boolean {
            return oldItem == newItem
        }
    }
}

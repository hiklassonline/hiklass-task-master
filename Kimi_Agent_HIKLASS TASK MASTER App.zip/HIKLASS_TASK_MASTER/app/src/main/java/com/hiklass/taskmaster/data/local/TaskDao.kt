package com.hiklass.taskmaster.data.local

import androidx.lifecycle.LiveData
import androidx.room.*
import com.hiklass.taskmaster.data.model.Task
import com.hiklass.taskmaster.data.model.TaskStatus
import kotlinx.coroutines.flow.Flow
import java.util.Date

@Dao
interface TaskDao {
    
    @Query("SELECT * FROM tasks ORDER BY 
        CASE priority 
            WHEN 'URGENT' THEN 1 
            WHEN 'HIGH' THEN 2 
            WHEN 'MEDIUM' THEN 3 
            WHEN 'LOW' THEN 4 
        END, 
        deadline ASC, 
        createdAt DESC")
    fun getAllTasks(): Flow<List<Task>>
    
    @Query("SELECT * FROM tasks ORDER BY 
        CASE priority 
            WHEN 'URGENT' THEN 1 
            WHEN 'HIGH' THEN 2 
            WHEN 'MEDIUM' THEN 3 
            WHEN 'LOW' THEN 4 
        END, 
        deadline ASC, 
        createdAt DESC")
    fun getAllTasksLiveData(): LiveData<List<Task>>
    
    @Query("SELECT * FROM tasks WHERE status = :status ORDER BY deadline ASC")
    fun getTasksByStatus(status: TaskStatus): Flow<List<Task>>
    
    @Query("SELECT * FROM tasks WHERE status != 'COMPLETED' AND status != 'CANCELLED' ORDER BY deadline ASC")
    fun getActiveTasks(): Flow<List<Task>>
    
    @Query("SELECT * FROM tasks WHERE status = 'COMPLETED' ORDER BY completedAt DESC")
    fun getCompletedTasks(): Flow<List<Task>>
    
    @Query("SELECT * FROM tasks WHERE id = :taskId")
    suspend fun getTaskById(taskId: Long): Task?
    
    @Query("SELECT * FROM tasks WHERE id = :taskId")
    fun getTaskByIdLiveData(taskId: Long): LiveData<Task?>
    
    @Query("SELECT * FROM tasks WHERE isSynced = 0")
    suspend fun getUnsyncedTasks(): List<Task>
    
    @Query("SELECT * FROM tasks WHERE deadline BETWEEN :startDate AND :endDate AND status != 'COMPLETED'")
    suspend fun getTasksWithDeadlineBetween(startDate: Date, endDate: Date): List<Task>
    
    @Query("SELECT * FROM tasks WHERE deadline <= :date AND status != 'COMPLETED'")
    suspend fun getOverdueTasks(date: Date = Date()): List<Task>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: Task): Long
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTasks(tasks: List<Task>)
    
    @Update
    suspend fun updateTask(task: Task)
    
    @Delete
    suspend fun deleteTask(task: Task)
    
    @Query("DELETE FROM tasks WHERE id = :taskId")
    suspend fun deleteTaskById(taskId: Long)
    
    @Query("UPDATE tasks SET isSynced = 1, serverId = :serverId WHERE id = :taskId")
    suspend fun markTaskAsSynced(taskId: Long, serverId: String)
    
    @Query("UPDATE tasks SET status = :status, completedAt = :completedAt, isSynced = 0 WHERE id = :taskId")
    suspend fun updateTaskStatus(taskId: Long, status: TaskStatus, completedAt: Date?)
    
    @Query("SELECT COUNT(*) FROM tasks WHERE status != 'COMPLETED' AND status != 'CANCELLED'")
    fun getActiveTaskCount(): LiveData<Int>
    
    @Query("SELECT COUNT(*) FROM tasks WHERE isSynced = 0")
    suspend fun getUnsyncedTaskCount(): Int
    
    @Query("DELETE FROM tasks")
    suspend fun deleteAllTasks()
    
    @Query("SELECT * FROM tasks WHERE title LIKE '%' || :query || '%' OR description LIKE '%' || :query || '%'")
    fun searchTasks(query: String): Flow<List<Task>>
}

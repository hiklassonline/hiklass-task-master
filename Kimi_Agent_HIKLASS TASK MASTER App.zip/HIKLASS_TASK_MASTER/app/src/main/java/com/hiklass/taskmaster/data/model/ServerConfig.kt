package com.hiklass.taskmaster.data.model

data class ServerConfig(
    val serverUrl: String,
    val apiKey: String? = null,
    val username: String? = null,
    val password: String? = null,
    val isEnabled: Boolean = false
)

data class SyncResult(
    val success: Boolean,
    val message: String,
    val syncedCount: Int = 0,
    val failedCount: Int = 0
)

sealed class SyncStatus {
    object Idle : SyncStatus()
    object Syncing : SyncStatus()
    data class Success(val message: String) : SyncStatus()
    data class Error(val message: String) : SyncStatus()
    object Offline : SyncStatus()
}

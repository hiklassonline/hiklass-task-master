package com.hiklass.taskmaster.ui.task

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.hiklass.taskmaster.R
import com.hiklass.taskmaster.data.model.Task
import com.hiklass.taskmaster.data.model.TaskPriority
import com.hiklass.taskmaster.data.model.TaskStatus
import com.hiklass.taskmaster.databinding.ActivityTaskDetailBinding
import java.util.Calendar
import java.util.Date

class TaskDetailActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityTaskDetailBinding
    private val viewModel: TaskDetailViewModel by viewModels()
    
    private var taskId: Long = 0
    private var selectedDeadline: Date? = null
    private var isEditMode = false
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTaskDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setupToolbar()
        setupSpinners()
        setupDatePicker()
        setupReminderSwitches()
        observeViewModel()
        
        // Get task ID from intent
        taskId = intent.getLongExtra(EXTRA_TASK_ID, 0)
        isEditMode = taskId != 0L
        
        if (isEditMode) {
            supportActionBar?.title = getString(R.string.edit_task)
            viewModel.loadTask(taskId)
        } else {
            supportActionBar?.title = getString(R.string.new_task)
            binding.btnDelete.visibility = View.GONE
        }
    }
    
    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
    }
    
    private fun setupSpinners() {
        // Priority spinner
        val priorities = TaskPriority.values().map { it.getDisplayName() }
        val priorityAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, priorities)
        priorityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerPriority.adapter = priorityAdapter
        
        // Status spinner
        val statuses = TaskStatus.values().map { it.getDisplayName() }
        val statusAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, statuses)
        statusAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerStatus.adapter = statusAdapter
    }
    
    private fun setupDatePicker() {
        binding.btnSelectDate.setOnClickListener {
            showDateTimePicker()
        }
        
        binding.btnClearDate.setOnClickListener {
            selectedDeadline = null
            updateDeadlineDisplay()
        }
    }
    
    private fun setupReminderSwitches() {
        // Enable/disable reminder switches based on deadline
        binding.switchReminder2Days.isEnabled = selectedDeadline != null
        binding.switchReminder1Day.isEnabled = selectedDeadline != null
        binding.switchReminderOnDay.isEnabled = selectedDeadline != null
    }
    
    private fun showDateTimePicker() {
        val calendar = Calendar.getInstance()
        selectedDeadline?.let {
            calendar.time = it
        }
        
        DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                calendar.set(Calendar.YEAR, year)
                calendar.set(Calendar.MONTH, month)
                calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                
                TimePickerDialog(
                    this,
                    { _, hourOfDay, minute ->
                        calendar.set(Calendar.HOUR_OF_DAY, hourOfDay)
                        calendar.set(Calendar.MINUTE, minute)
                        calendar.set(Calendar.SECOND, 0)
                        calendar.set(Calendar.MILLISECOND, 0)
                        
                        selectedDeadline = calendar.time
                        updateDeadlineDisplay()
                        setupReminderSwitches()
                    },
                    calendar.get(Calendar.HOUR_OF_DAY),
                    calendar.get(Calendar.MINUTE),
                    true
                ).show()
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).apply {
            datePicker.minDate = System.currentTimeMillis()
        }.show()
    }
    
    private fun updateDeadlineDisplay() {
        binding.tvSelectedDate.text = selectedDeadline?.let {
            java.text.SimpleDateFormat("MMM dd, yyyy HH:mm", java.util.Locale.getDefault())
                .format(it)
        } ?: getString(R.string.no_deadline_selected)
        
        binding.btnClearDate.visibility = if (selectedDeadline != null) View.VISIBLE else View.GONE
    }
    
    private fun observeViewModel() {
        viewModel.task.observe(this) { task ->
            task?.let { populateFields(it) }
        }
        
        viewModel.saveSuccess.observe(this) { success ->
            if (success) {
                Toast.makeText(this, R.string.task_saved, Toast.LENGTH_SHORT).show()
                finish()
            }
        }
        
        viewModel.errorMessage.observe(this) { message ->
            message?.let {
                Toast.makeText(this, it, Toast.LENGTH_LONG).show()
            }
        }
    }
    
    private fun populateFields(task: Task) {
        binding.etTitle.setText(task.title)
        binding.etDescription.setText(task.description)
        
        // Set priority
        val priorityPosition = TaskPriority.values().indexOf(task.priority)
        binding.spinnerPriority.setSelection(priorityPosition)
        
        // Set status
        val statusPosition = TaskStatus.values().indexOf(task.status)
        binding.spinnerStatus.setSelection(statusPosition)
        
        // Set deadline
        selectedDeadline = task.deadline
        updateDeadlineDisplay()
        
        // Set reminders
        binding.switchReminder2Days.isChecked = task.reminder2Days
        binding.switchReminder1Day.isChecked = task.reminder1Day
        binding.switchReminderOnDay.isChecked = task.reminderOnDay
        
        setupReminderSwitches()
        
        // Setup delete button
        binding.btnDelete.setOnClickListener {
            showDeleteConfirmation(task)
        }
    }
    
    private fun saveTask() {
        val title = binding.etTitle.text.toString().trim()
        
        if (title.isEmpty()) {
            binding.etTitle.error = getString(R.string.title_required)
            binding.etTitle.requestFocus()
            return
        }
        
        val description = binding.etDescription.text.toString().trim()
        val priority = TaskPriority.values()[binding.spinnerPriority.selectedItemPosition]
        val status = TaskStatus.values()[binding.spinnerStatus.selectedItemPosition]
        
        val task = Task(
            id = taskId,
            title = title,
            description = description,
            deadline = selectedDeadline,
            status = status,
            priority = priority,
            reminder2Days = selectedDeadline != null && binding.switchReminder2Days.isChecked,
            reminder1Day = selectedDeadline != null && binding.switchReminder1Day.isChecked,
            reminderOnDay = selectedDeadline != null && binding.switchReminderOnDay.isChecked
        )
        
        viewModel.saveTask(task)
    }
    
    private fun showDeleteConfirmation(task: Task) {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_task)
            .setMessage(getString(R.string.delete_task_confirmation, task.title))
            .setPositiveButton(R.string.delete) { _, _ ->
                viewModel.deleteTask(task)
                Toast.makeText(this, R.string.task_deleted, Toast.LENGTH_SHORT).show()
                finish()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
    
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_task_detail, menu)
        return true
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            R.id.action_save -> {
                saveTask()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    
    companion object {
        private const val EXTRA_TASK_ID = "task_id"
        
        fun start(context: Context, taskId: Long = 0) {
            val intent = Intent(context, TaskDetailActivity::class.java).apply {
                putExtra(EXTRA_TASK_ID, taskId)
            }
            context.startActivity(intent)
        }
    }
}

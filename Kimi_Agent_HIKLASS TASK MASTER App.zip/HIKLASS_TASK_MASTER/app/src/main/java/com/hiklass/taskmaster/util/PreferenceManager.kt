package com.hiklass.taskmaster.util

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit

class PreferenceManager(context: Context) {
    
    private val prefs: SharedPreferences = context.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )
    
    // Server settings
    fun getServerUrl(): String? {
        return prefs.getString(KEY_SERVER_URL, null)
    }
    
    fun setServerUrl(url: String?) {
        prefs.edit { putString(KEY_SERVER_URL, url) }
    }
    
    fun getApiKey(): String? {
        return prefs.getString(KEY_API_KEY, null)
    }
    
    fun setApiKey(apiKey: String?) {
        prefs.edit { putString(KEY_API_KEY, apiKey) }
    }
    
    fun isServerEnabled(): Boolean {
        return prefs.getBoolean(KEY_SERVER_ENABLED, false)
    }
    
    fun setServerEnabled(enabled: Boolean) {
        prefs.edit { putBoolean(KEY_SERVER_ENABLED, enabled) }
    }
    
    // Notification settings
    fun areNotificationsEnabled(): Boolean {
        return prefs.getBoolean(KEY_NOTIFICATIONS_ENABLED, true)
    }
    
    fun setNotificationsEnabled(enabled: Boolean) {
        prefs.edit { putBoolean(KEY_NOTIFICATIONS_ENABLED, enabled) }
    }
    
    // Reminder settings
    fun isReminder2DaysEnabled(): Boolean {
        return prefs.getBoolean(KEY_REMINDER_2_DAYS, true)
    }
    
    fun setReminder2DaysEnabled(enabled: Boolean) {
        prefs.edit { putBoolean(KEY_REMINDER_2_DAYS, enabled) }
    }
    
    fun isReminder1DayEnabled(): Boolean {
        return prefs.getBoolean(KEY_REMINDER_1_DAY, true)
    }
    
    fun setReminder1DayEnabled(enabled: Boolean) {
        prefs.edit { putBoolean(KEY_REMINDER_1_DAY, enabled) }
    }
    
    fun isReminderOnDayEnabled(): Boolean {
        return prefs.getBoolean(KEY_REMINDER_ON_DAY, true)
    }
    
    fun setReminderOnDayEnabled(enabled: Boolean) {
        prefs.edit { putBoolean(KEY_REMINDER_ON_DAY, enabled) }
    }
    
    // Sync settings
    fun isAutoSyncEnabled(): Boolean {
        return prefs.getBoolean(KEY_AUTO_SYNC, true)
    }
    
    fun setAutoSyncEnabled(enabled: Boolean) {
        prefs.edit { putBoolean(KEY_AUTO_SYNC, enabled) }
    }
    
    fun getLastSyncTime(): Long {
        return prefs.getLong(KEY_LAST_SYNC_TIME, 0)
    }
    
    fun setLastSyncTime(time: Long) {
        prefs.edit { putLong(KEY_LAST_SYNC_TIME, time) }
    }
    
    // App settings
    fun getDefaultPriority(): String {
        return prefs.getString(KEY_DEFAULT_PRIORITY, "MEDIUM") ?: "MEDIUM"
    }
    
    fun setDefaultPriority(priority: String) {
        prefs.edit { putString(KEY_DEFAULT_PRIORITY, priority) }
    }
    
    fun isFirstLaunch(): Boolean {
        return prefs.getBoolean(KEY_FIRST_LAUNCH, true)
    }
    
    fun setFirstLaunch(isFirst: Boolean) {
        prefs.edit { putBoolean(KEY_FIRST_LAUNCH, isFirst) }
    }
    
    // Clear all settings
    fun clearAll() {
        prefs.edit { clear() }
    }
    
    companion object {
        private const val PREFS_NAME = "hiklass_task_master_prefs"
        
        private const val KEY_SERVER_URL = "server_url"
        private const val KEY_API_KEY = "api_key"
        private const val KEY_SERVER_ENABLED = "server_enabled"
        
        private const val KEY_NOTIFICATIONS_ENABLED = "notifications_enabled"
        private const val KEY_REMINDER_2_DAYS = "reminder_2_days"
        private const val KEY_REMINDER_1_DAY = "reminder_1_day"
        private const val KEY_REMINDER_ON_DAY = "reminder_on_day"
        
        private const val KEY_AUTO_SYNC = "auto_sync"
        private const val KEY_LAST_SYNC_TIME = "last_sync_time"
        
        private const val KEY_DEFAULT_PRIORITY = "default_priority"
        private const val KEY_FIRST_LAUNCH = "first_launch"
    }
}

package com.hiklass.taskmaster.ui.settings

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.hiklass.taskmaster.R
import com.hiklass.taskmaster.data.remote.RetrofitClient
import com.hiklass.taskmaster.databinding.ActivitySettingsBinding
import com.hiklass.taskmaster.util.PreferenceManager
import com.hiklass.taskmaster.worker.SyncWorker

class SettingsActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivitySettingsBinding
    private lateinit var prefs: PreferenceManager
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        prefs = PreferenceManager(this)
        
        setupToolbar()
        loadSettings()
        setupListeners()
    }
    
    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.title = getString(R.string.settings)
    }
    
    private fun loadSettings() {
        // Server settings
        binding.etServerUrl.setText(prefs.getServerUrl() ?: "")
        binding.etApiKey.setText(prefs.getApiKey() ?: "")
        binding.switchServerEnabled.isChecked = prefs.isServerEnabled()
        
        // Notification settings
        binding.switchNotifications.isChecked = prefs.areNotificationsEnabled()
        binding.switchReminder2Days.isChecked = prefs.isReminder2DaysEnabled()
        binding.switchReminder1Day.isChecked = prefs.isReminder1DayEnabled()
        binding.switchReminderOnDay.isChecked = prefs.isReminderOnDayEnabled()
        
        // Sync settings
        binding.switchAutoSync.isChecked = prefs.isAutoSyncEnabled()
        
        updateServerFieldsVisibility()
    }
    
    private fun setupListeners() {
        // Server enabled switch
        binding.switchServerEnabled.setOnCheckedChangeListener { _, isChecked ->
            prefs.setServerEnabled(isChecked)
            updateServerFieldsVisibility()
            if (isChecked) {
                validateAndSaveServerSettings()
            }
        }
        
        // Test connection button
        binding.btnTestConnection.setOnClickListener {
            testServerConnection()
        }
        
        // Save server settings
        binding.btnSaveServer.setOnClickListener {
            validateAndSaveServerSettings()
        }
        
        // Notification switches
        binding.switchNotifications.setOnCheckedChangeListener { _, isChecked ->
            prefs.setNotificationsEnabled(isChecked)
        }
        
        binding.switchReminder2Days.setOnCheckedChangeListener { _, isChecked ->
            prefs.setReminder2DaysEnabled(isChecked)
        }
        
        binding.switchReminder1Day.setOnCheckedChangeListener { _, isChecked ->
            prefs.setReminder1DayEnabled(isChecked)
        }
        
        binding.switchReminderOnDay.setOnCheckedChangeListener { _, isChecked ->
            prefs.setReminderOnDayEnabled(isChecked)
        }
        
        // Auto sync switch
        binding.switchAutoSync.setOnCheckedChangeListener { _, isChecked ->
            prefs.setAutoSyncEnabled(isChecked)
            if (isChecked) {
                SyncWorker.schedule(this)
            } else {
                SyncWorker.cancel(this)
            }
        }
        
        // Manual sync button
        binding.btnManualSync.setOnClickListener {
            SyncWorker.runImmediateSync(this)
            Toast.makeText(this, R.string.sync_started, Toast.LENGTH_SHORT).show()
        }
        
        // Privacy policy
        binding.btnPrivacyPolicy.setOnClickListener {
            openPrivacyPolicy()
        }
        
        // Clear data
        binding.btnClearData.setOnClickListener {
            showClearDataConfirmation()
        }
    }
    
    private fun updateServerFieldsVisibility() {
        val isEnabled = binding.switchServerEnabled.isChecked
        binding.etServerUrl.isEnabled = isEnabled
        binding.etApiKey.isEnabled = isEnabled
        binding.btnTestConnection.isEnabled = isEnabled
        binding.btnSaveServer.isEnabled = isEnabled
    }
    
    private fun validateAndSaveServerSettings(): Boolean {
        val serverUrl = binding.etServerUrl.text.toString().trim()
        val apiKey = binding.etApiKey.text.toString().trim()
        
        if (serverUrl.isEmpty()) {
            binding.etServerUrl.error = getString(R.string.server_url_required)
            return false
        }
        
        // Validate URL format
        if (!serverUrl.startsWith("http://") && !serverUrl.startsWith("https://")) {
            binding.etServerUrl.error = getString(R.string.invalid_url_format)
            return false
        }
        
        prefs.setServerUrl(serverUrl)
        prefs.setApiKey(apiKey.takeIf { it.isNotEmpty() })
        
        Toast.makeText(this, R.string.settings_saved, Toast.LENGTH_SHORT).show()
        return true
    }
    
    private fun testServerConnection() {
        val serverUrl = binding.etServerUrl.text.toString().trim()
        
        if (serverUrl.isEmpty()) {
            binding.etServerUrl.error = getString(R.string.server_url_required)
            return
        }
        
        binding.progressBar.visibility = View.VISIBLE
        binding.tvConnectionStatus.visibility = View.GONE
        
        RetrofitClient.testConnection(serverUrl, this) { success, message ->
            runOnUiThread {
                binding.progressBar.visibility = View.GONE
                binding.tvConnectionStatus.apply {
                    visibility = View.VISIBLE
                    text = message
                    setTextColor(
                        if (success) 
                            getColor(android.R.color.holo_green_dark)
                        else 
                            getColor(android.R.color.holo_red_dark)
                    )
                }
            }
        }
    }
    
    private fun openPrivacyPolicy() {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.hiklass.online/privacy-policy"))
        startActivity(intent)
    }
    
    private fun showClearDataConfirmation() {
        AlertDialog.Builder(this)
            .setTitle(R.string.clear_all_data)
            .setMessage(R.string.clear_data_confirmation)
            .setPositiveButton(R.string.clear) { _, _ ->
                clearAllData()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
    
    private fun clearAllData() {
        // Clear preferences
        prefs.clearAll()
        
        // Clear database
        deleteDatabase("task_master_database")
        
        Toast.makeText(this, R.string.data_cleared, Toast.LENGTH_SHORT).show()
        
        // Restart activity
        finish()
        startActivity(intent)
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}

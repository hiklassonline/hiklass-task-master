package com.hiklass.taskmaster.service

import android.app.Notification
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.hiklass.taskmaster.R
import com.hiklass.taskmaster.data.local.TaskDatabase
import com.hiklass.taskmaster.data.repository.TaskRepository
import com.hiklass.taskmaster.util.NotificationHelper
import com.hiklass.taskmaster.util.PreferenceManager
import kotlinx.coroutines.*

class SyncService : Service() {
    
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private lateinit var repository: TaskRepository
    
    override fun onCreate() {
        super.onCreate()
        val database = TaskDatabase.getDatabase(applicationContext)
        repository = TaskRepository(database.taskDao(), applicationContext)
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Start as foreground service
        startForeground(NOTIFICATION_ID, createNotification())
        
        serviceScope.launch {
            try {
                // Sync tasks
                val result = repository.syncTasks()
                
                // Update last sync time
                if (result.success) {
                    PreferenceManager(applicationContext).setLastSyncTime(System.currentTimeMillis())
                }
                
                // Show result notification if needed
                if (!result.success || result.failedCount > 0) {
                    NotificationHelper.showSyncNotification(
                        applicationContext,
                        result.message,
                        !result.success
                    )
                }
            } catch (e: Exception) {
                NotificationHelper.showSyncNotification(
                    applicationContext,
                    "Sync failed: ${e.message}",
                    true
                )
            } finally {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf(startId)
            }
        }
        
        return START_NOT_STICKY
    }
    
    override fun onBind(intent: Intent?): IBinder? = null
    
    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }
    
    private fun createNotification(): Notification {
        return NotificationCompat.Builder(this, NotificationHelper.CHANNEL_ID_SYNC)
            .setContentTitle(getString(R.string.syncing_tasks))
            .setContentText(getString(R.string.sync_in_progress))
            .setSmallIcon(R.drawable.ic_sync)
            .setOngoing(true)
            .setProgress(0, 0, true)
            .build()
    }
    
    companion object {
        private const val NOTIFICATION_ID = 1001
    }
}

package com.hiklass.taskmaster.ui.task

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.hiklass.taskmaster.data.local.TaskDatabase
import com.hiklass.taskmaster.data.model.Task
import com.hiklass.taskmaster.data.repository.TaskRepository
import kotlinx.coroutines.launch

class TaskDetailViewModel(application: Application) : AndroidViewModel(application) {
    
    private val repository: TaskRepository
    
    private val _task = MutableLiveData<Task?>()
    val task: LiveData<Task?> = _task
    
    private val _saveSuccess = MutableLiveData<Boolean>()
    val saveSuccess: LiveData<Boolean> = _saveSuccess
    
    private val _errorMessage = MutableLiveData<String?>()
    val errorMessage: LiveData<String?> = _errorMessage
    
    init {
        val database = TaskDatabase.getDatabase(application)
        repository = TaskRepository(database.taskDao(), application)
    }
    
    fun loadTask(taskId: Long) {
        viewModelScope.launch {
            _task.value = repository.getTaskById(taskId)
        }
    }
    
    fun saveTask(task: Task) {
        viewModelScope.launch {
            try {
                if (task.id == 0L) {
                    // New task
                    repository.insertTask(task)
                } else {
                    // Update existing task
                    repository.updateTask(task)
                }
                _saveSuccess.value = true
            } catch (e: Exception) {
                _errorMessage.value = "Failed to save task: ${e.message}"
            }
        }
    }
    
    fun deleteTask(task: Task) {
        viewModelScope.launch {
            try {
                repository.deleteTask(task)
            } catch (e: Exception) {
                _errorMessage.value = "Failed to delete task: ${e.message}"
            }
        }
    }
}

package com.hiklass.taskmaster.data.repository

import android.content.Context
import androidx.lifecycle.LiveData
import com.hiklass.taskmaster.data.local.TaskDao
import com.hiklass.taskmaster.data.model.*
import com.hiklass.taskmaster.data.remote.RetrofitClient
import com.hiklass.taskmaster.data.remote.TaskResponse
import com.hiklass.taskmaster.data.remote.TaskSyncRequest
import com.hiklass.taskmaster.util.NetworkUtils
import com.hiklass.taskmaster.util.PreferenceManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.util.Date

class TaskRepository(
    private val taskDao: TaskDao,
    private val context: Context
) {
    private val prefs = PreferenceManager(context)
    
    // Local operations
    val allTasks: Flow<List<Task>> = taskDao.getAllTasks()
    val allTasksLiveData: LiveData<List<Task>> = taskDao.getAllTasksLiveData()
    val activeTasks: Flow<List<Task>> = taskDao.getActiveTasks()
    val completedTasks: Flow<List<Task>> = taskDao.getCompletedTasks()
    val activeTaskCount: LiveData<Int> = taskDao.getActiveTaskCount()
    
    suspend fun getTaskById(taskId: Long): Task? {
        return taskDao.getTaskById(taskId)
    }
    
    fun getTaskByIdLiveData(taskId: Long): LiveData<Task?> {
        return taskDao.getTaskByIdLiveData(taskId)
    }
    
    suspend fun insertTask(task: Task): Long {
        return withContext(Dispatchers.IO) {
            val id = taskDao.insertTask(task.copy(isSynced = false, lastModified = Date()))
            scheduleReminders(id, task)
            id
        }
    }
    
    suspend fun updateTask(task: Task) {
        withContext(Dispatchers.IO) {
            taskDao.updateTask(task.copy(isSynced = false, lastModified = Date()))
            scheduleReminders(task.id, task)
        }
    }
    
    suspend fun deleteTask(task: Task) {
        withContext(Dispatchers.IO) {
            cancelReminders(task.id)
            taskDao.deleteTask(task)
        }
    }
    
    suspend fun deleteTaskById(taskId: Long) {
        withContext(Dispatchers.IO) {
            cancelReminders(taskId)
            taskDao.deleteTaskById(taskId)
        }
    }
    
    suspend fun updateTaskStatus(taskId: Long, status: TaskStatus) {
        val completedAt = if (status == TaskStatus.COMPLETED) Date() else null
        taskDao.updateTaskStatus(taskId, status, completedAt)
    }
    
    suspend fun getTasksWithUpcomingDeadlines(): List<Task> {
        val now = Date()
        val twoDaysLater = Date(now.time + 2 * 24 * 60 * 60 * 1000)
        return taskDao.getTasksWithDeadlineBetween(now, twoDaysLater)
    }
    
    suspend fun getOverdueTasks(): List<Task> {
        return taskDao.getOverdueTasks()
    }
    
    fun searchTasks(query: String): Flow<List<Task>> {
        return taskDao.searchTasks(query)
    }
    
    // Sync operations
    suspend fun syncTasks(): SyncResult {
        return withContext(Dispatchers.IO) {
            if (!NetworkUtils.isNetworkAvailable(context)) {
                return@withContext SyncResult(false, "No internet connection", 0, 0)
            }
            
            val apiService = RetrofitClient.createApiService(context)
                ?: return@withContext SyncResult(false, "Server not configured", 0, 0)
            
            try {
                val unsyncedTasks = taskDao.getUnsyncedTasks()
                val syncRequests = unsyncedTasks.map { it.toSyncRequest() }
                
                if (syncRequests.isEmpty()) {
                    return@withContext SyncResult(true, "No tasks to sync", 0, 0)
                }
                
                val response = apiService.syncTasks(syncRequests)
                
                if (response.isSuccessful) {
                    val syncResponse = response.body()
                    syncResponse?.syncedTasks?.forEach { syncedTask ->
                        syncedTask.localId?.let { localId ->
                            taskDao.markTaskAsSynced(localId, syncedTask.id)
                        }
                    }
                    
                    SyncResult(
                        success = true,
                        message = "Synced ${syncResponse?.syncedTasks?.size ?: 0} tasks",
                        syncedCount = syncResponse?.syncedTasks?.size ?: 0,
                        failedCount = syncResponse?.failedCount ?: 0
                    )
                } else {
                    SyncResult(false, "Sync failed: ${response.code()}", 0, syncRequests.size)
                }
            } catch (e: Exception) {
                SyncResult(false, "Sync error: ${e.message}", 0, 0)
            }
        }
    }
    
    suspend fun fetchTasksFromServer(): SyncResult {
        return withContext(Dispatchers.IO) {
            if (!NetworkUtils.isNetworkAvailable(context)) {
                return@withContext SyncResult(false, "No internet connection", 0, 0)
            }
            
            val apiService = RetrofitClient.createApiService(context)
                ?: return@withContext SyncResult(false, "Server not configured", 0, 0)
            
            try {
                val response = apiService.getAllTasks()
                
                if (response.isSuccessful) {
                    val serverTasks = response.body()
                    serverTasks?.let { tasks ->
                        val localTasks = tasks.map { it.toTask() }
                        taskDao.insertTasks(localTasks)
                    }
                    
                    SyncResult(
                        success = true,
                        message = "Fetched ${serverTasks?.size ?: 0} tasks",
                        syncedCount = serverTasks?.size ?: 0
                    )
                } else {
                    SyncResult(false, "Fetch failed: ${response.code()}", 0, 0)
                }
            } catch (e: Exception) {
                SyncResult(false, "Fetch error: ${e.message}", 0, 0)
            }
        }
    }
    
    suspend fun getUnsyncedCount(): Int {
        return taskDao.getUnsyncedTaskCount()
    }
    
    // Private helper methods
    private fun scheduleReminders(taskId: Long, task: Task) {
        // This will be implemented in the NotificationHelper
        com.hiklass.taskmaster.util.ReminderManager.scheduleReminders(context, taskId, task)
    }
    
    private fun cancelReminders(taskId: Long) {
        com.hiklass.taskmaster.util.ReminderManager.cancelReminders(context, taskId)
    }
    
    // Extension functions for conversion
    private fun Task.toSyncRequest(): TaskSyncRequest {
        return TaskSyncRequest(
            localId = id,
            title = title,
            description = description.takeIf { it.isNotBlank() },
            deadline = deadline?.time,
            status = status.name,
            priority = priority.name,
            reminder2Days = reminder2Days,
            reminder1Day = reminder1Day,
            reminderOnDay = reminderOnDay,
            createdAt = createdAt.time,
            lastModified = lastModified.time
        )
    }
    
    private fun TaskResponse.toTask(): Task {
        return Task(
            id = localId ?: 0,
            title = title,
            description = description ?: "",
            deadline = deadline?.let { Date(it) },
            status = TaskStatus.valueOf(status),
            priority = TaskPriority.valueOf(priority),
            reminder2Days = reminder2Days,
            reminder1Day = reminder1Day,
            reminderOnDay = reminderOnDay,
            isSynced = true,
            serverId = id,
            createdAt = Date(createdAt),
            lastModified = Date(lastModified)
        )
    }
}

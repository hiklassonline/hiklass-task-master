package com.hiklass.taskmaster.ui.main

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.tabs.TabLayout
import com.hiklass.taskmaster.R
import com.hiklass.taskmaster.data.model.SyncStatus
import com.hiklass.taskmaster.data.model.Task
import com.hiklass.taskmaster.databinding.ActivityMainBinding
import com.hiklass.taskmaster.ui.settings.SettingsActivity
import com.hiklass.taskmaster.ui.task.TaskDetailActivity
import com.hiklass.taskmaster.worker.SyncWorker
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var taskAdapter: TaskAdapter
    
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (!isGranted) {
            Toast.makeText(
                this,
                R.string.notification_permission_denied,
                Toast.LENGTH_LONG
            ).show()
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setupToolbar()
        setupRecyclerView()
        setupTabLayout()
        setupFab()
        setupSwipeRefresh()
        observeViewModel()
        requestNotificationPermission()
        
        // Check if opened from notification
        handleIntent(intent)
    }
    
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }
    
    private fun handleIntent(intent: Intent?) {
        intent?.getLongExtra("task_id", -1)?.let { taskId ->
            if (taskId != -1L) {
                // Open task detail
                TaskDetailActivity.start(this, taskId)
            }
        }
    }
    
    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.title = getString(R.string.app_name)
    }
    
    private fun setupRecyclerView() {
        taskAdapter = TaskAdapter(
            onTaskClick = { task ->
                TaskDetailActivity.start(this, task.id)
            },
            onTaskComplete = { task ->
                viewModel.completeTask(task.id)
                Toast.makeText(this, R.string.task_completed, Toast.LENGTH_SHORT).show()
            },
            onTaskDelete = { task ->
                showDeleteConfirmation(task)
            },
            onTaskEdit = { task ->
                TaskDetailActivity.start(this, task.id)
            }
        )
        
        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = taskAdapter
            setHasFixedSize(true)
        }
    }
    
    private fun setupTabLayout() {
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                when (tab?.position) {
                    0 -> observeAllTasks()
                    1 -> observeActiveTasks()
                    2 -> observeCompletedTasks()
                }
            }
            
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
        
        // Start with all tasks
        observeAllTasks()
    }
    
    private fun setupFab() {
        binding.fabAddTask.setOnClickListener {
            TaskDetailActivity.start(this)
        }
    }
    
    private fun setupSwipeRefresh() {
        binding.swipeRefresh.setOnRefreshListener {
            if (viewModel.isServerConfigured()) {
                viewModel.syncTasks()
            } else {
                binding.swipeRefresh.isRefreshing = false
                Toast.makeText(this, R.string.server_not_configured, Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                // Observe sync status
                viewModel.syncStatus.observe(this@MainActivity) { status ->
                    when (status) {
                        is SyncStatus.Syncing -> {
                            binding.swipeRefresh.isRefreshing = true
                            binding.tvSyncStatus.visibility = View.VISIBLE
                            binding.tvSyncStatus.text = getString(R.string.syncing)
                        }
                        is SyncStatus.Success -> {
                            binding.swipeRefresh.isRefreshing = false
                            binding.tvSyncStatus.visibility = View.VISIBLE
                            binding.tvSyncStatus.text = status.message
                            updateLastSyncTime()
                        }
                        is SyncStatus.Error -> {
                            binding.swipeRefresh.isRefreshing = false
                            binding.tvSyncStatus.visibility = View.VISIBLE
                            binding.tvSyncStatus.text = status.message
                        }
                        is SyncStatus.Offline -> {
                            binding.swipeRefresh.isRefreshing = false
                            binding.tvSyncStatus.visibility = View.VISIBLE
                            binding.tvSyncStatus.text = getString(R.string.offline_mode)
                        }
                        else -> {
                            binding.swipeRefresh.isRefreshing = false
                        }
                    }
                }
                
                // Observe loading state
                viewModel.isLoading.observe(this@MainActivity) { isLoading ->
                    binding.progressBar.isVisible = isLoading
                }
                
                // Observe active task count
                viewModel.activeTaskCount.observe(this@MainActivity) { count ->
                    binding.tvTaskCount.text = resources.getQuantityString(
                        R.plurals.active_tasks_count,
                        count ?: 0,
                        count ?: 0
                    )
                }
            }
        }
        
        updateLastSyncTime()
    }
    
    private fun observeAllTasks() {
        lifecycleScope.launch {
            viewModel.allTasks.collectLatest { tasks ->
                updateTaskList(tasks)
            }
        }
    }
    
    private fun observeActiveTasks() {
        lifecycleScope.launch {
            viewModel.activeTasks.collectLatest { tasks ->
                updateTaskList(tasks)
            }
        }
    }
    
    private fun observeCompletedTasks() {
        lifecycleScope.launch {
            viewModel.completedTasks.collectLatest { tasks ->
                updateTaskList(tasks)
            }
        }
    }
    
    private fun updateTaskList(tasks: List<Task>) {
        taskAdapter.submitList(tasks)
        
        binding.apply {
            if (tasks.isEmpty()) {
                recyclerView.visibility = View.GONE
                emptyView.root.visibility = View.VISIBLE
            } else {
                recyclerView.visibility = View.VISIBLE
                emptyView.root.visibility = View.GONE
            }
        }
    }
    
    private fun updateLastSyncTime() {
        val lastSync = viewModel.getLastSyncTime()
        if (lastSync > 0) {
            val dateFormat = SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault())
            binding.tvLastSync.text = getString(
                R.string.last_sync,
                dateFormat.format(Date(lastSync))
            )
            binding.tvLastSync.visibility = View.VISIBLE
        } else {
            binding.tvLastSync.visibility = View.GONE
        }
    }
    
    private fun showDeleteConfirmation(task: Task) {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_task)
            .setMessage(getString(R.string.delete_task_confirmation, task.title))
            .setPositiveButton(R.string.delete) { _, _ ->
                viewModel.deleteTask(task)
                Toast.makeText(this, R.string.task_deleted, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
    
    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            when {
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED -> {
                    // Permission already granted
                }
                shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS) -> {
                    // Show rationale
                    Toast.makeText(
                        this,
                        R.string.notification_permission_rationale,
                        Toast.LENGTH_LONG
                    ).show()
                    requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
                else -> {
                    requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
        }
    }
    
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_sync -> {
                if (viewModel.isServerConfigured()) {
                    viewModel.syncTasks()
                } else {
                    Toast.makeText(this, R.string.server_not_configured, Toast.LENGTH_SHORT).show()
                }
                true
            }
            R.id.action_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            }
            R.id.action_refresh -> {
                if (viewModel.isServerConfigured()) {
                    viewModel.fetchTasksFromServer()
                } else {
                    Toast.makeText(this, R.string.server_not_configured, Toast.LENGTH_SHORT).show()
                }
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    
    override fun onResume() {
        super.onResume()
        updateLastSyncTime()
    }
}

package com.hiklass.taskmaster.ui.main

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.hiklass.taskmaster.data.local.TaskDatabase
import com.hiklass.taskmaster.data.model.SyncResult
import com.hiklass.taskmaster.data.model.SyncStatus
import com.hiklass.taskmaster.data.model.Task
import com.hiklass.taskmaster.data.model.TaskStatus
import com.hiklass.taskmaster.data.repository.TaskRepository
import com.hiklass.taskmaster.util.NetworkUtils
import com.hiklass.taskmaster.util.PreferenceManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    
    private val repository: TaskRepository
    private val prefs: PreferenceManager
    
    val allTasks: Flow<List<Task>>
    val activeTasks: Flow<List<Task>>
    val completedTasks: Flow<List<Task>>
    val activeTaskCount: LiveData<Int>
    
    private val _syncStatus = MutableLiveData<SyncStatus>()
    val syncStatus: LiveData<SyncStatus> = _syncStatus
    
    private val _searchResults = MutableLiveData<List<Task>>()
    val searchResults: LiveData<List<Task>> = _searchResults
    
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading
    
    init {
        val database = TaskDatabase.getDatabase(application)
        repository = TaskRepository(database.taskDao(), application)
        prefs = PreferenceManager(application)
        
        allTasks = repository.allTasks
        activeTasks = repository.activeTasks
        completedTasks = repository.completedTasks
        activeTaskCount = repository.activeTaskCount
    }
    
    fun syncTasks() {
        viewModelScope.launch {
            _syncStatus.value = SyncStatus.Syncing
            _isLoading.value = true
            
            val result = repository.syncTasks()
            
            _syncStatus.value = if (result.success) {
                SyncStatus.Success(result.message)
            } else {
                SyncStatus.Error(result.message)
            }
            _isLoading.value = false
        }
    }
    
    fun fetchTasksFromServer() {
        viewModelScope.launch {
            _syncStatus.value = SyncStatus.Syncing
            _isLoading.value = true
            
            val result = repository.fetchTasksFromServer()
            
            _syncStatus.value = if (result.success) {
                SyncStatus.Success(result.message)
            } else {
                SyncStatus.Error(result.message)
            }
            _isLoading.value = false
        }
    }
    
    fun deleteTask(task: Task) {
        viewModelScope.launch {
            repository.deleteTask(task)
        }
    }
    
    fun completeTask(taskId: Long) {
        viewModelScope.launch {
            repository.updateTaskStatus(taskId, TaskStatus.COMPLETED)
        }
    }
    
    fun searchTasks(query: String) {
        viewModelScope.launch {
            repository.searchTasks(query).collect { tasks ->
                _searchResults.value = tasks
            }
        }
    }
    
    fun isNetworkAvailable(): Boolean {
        return NetworkUtils.isNetworkAvailable(getApplication())
    }
    
    fun isServerConfigured(): Boolean {
        return prefs.isServerEnabled() && !prefs.getServerUrl().isNullOrBlank()
    }
    
    fun getLastSyncTime(): Long {
        return prefs.getLastSyncTime()
    }
}

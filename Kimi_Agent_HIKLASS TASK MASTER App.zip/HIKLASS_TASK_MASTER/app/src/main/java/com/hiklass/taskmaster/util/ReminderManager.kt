package com.hiklass.taskmaster.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.hiklass.taskmaster.data.model.Task
import com.hiklass.taskmaster.receiver.AlarmReceiver
import java.util.Date

object ReminderManager {
    
    private const val REQUEST_CODE_BASE = 10000
    
    fun scheduleReminders(context: Context, taskId: Long, task: Task) {
        val deadline = task.deadline ?: return
        val prefs = PreferenceManager(context)
        
        // Cancel existing reminders first
        cancelReminders(context, taskId)
        
        // Schedule 2 days before
        if (task.reminder2Days && prefs.isReminder2DaysEnabled()) {
            val twoDaysBefore = Date(deadline.time - 2 * 24 * 60 * 60 * 1000)
            if (twoDaysBefore.after(Date())) {
                scheduleAlarm(context, taskId, task.title, 2, twoDaysBefore.time)
            }
        }
        
        // Schedule 1 day before
        if (task.reminder1Day && prefs.isReminder1DayEnabled()) {
            val oneDayBefore = Date(deadline.time - 1 * 24 * 60 * 60 * 1000)
            if (oneDayBefore.after(Date())) {
                scheduleAlarm(context, taskId, task.title, 1, oneDayBefore.time)
            }
        }
        
        // Schedule on deadline day (9:00 AM)
        if (task.reminderOnDay && prefs.isReminderOnDayEnabled()) {
            val onDay = Date(deadline.time)
            onDay.hours = 9
            onDay.minutes = 0
            if (onDay.after(Date())) {
                scheduleAlarm(context, taskId, task.title, 0, onDay.time)
            }
        }
    }
    
    fun cancelReminders(context: Context, taskId: Long) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        
        // Cancel all reminder types for this task
        listOf(0, 1, 2).forEach { daysRemaining ->
            val intent = Intent(context, AlarmReceiver::class.java).apply {
                putExtra(AlarmReceiver.EXTRA_TASK_ID, taskId)
                putExtra(AlarmReceiver.EXTRA_DAYS_REMAINING, daysRemaining)
            }
            
            val requestCode = REQUEST_CODE_BASE + (taskId * 10 + daysRemaining).toInt()
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }
    
    private fun scheduleAlarm(
        context: Context,
        taskId: Long,
        taskTitle: String,
        daysRemaining: Int,
        triggerTime: Long
    ) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra(AlarmReceiver.EXTRA_TASK_ID, taskId)
            putExtra(AlarmReceiver.EXTRA_TASK_TITLE, taskTitle)
            putExtra(AlarmReceiver.EXTRA_DAYS_REMAINING, daysRemaining)
        }
        
        val requestCode = REQUEST_CODE_BASE + (taskId * 10 + daysRemaining).toInt()
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                // Android 12+ requires SCHEDULE_EXACT_ALARM permission
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerTime,
                        pendingIntent
                    )
                } else {
                    // Fallback to inexact alarm
                    alarmManager.setAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerTime,
                        pendingIntent
                    )
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerTime,
                    pendingIntent
                )
            } else {
                alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    triggerTime,
                    pendingIntent
                )
            }
        } catch (e: SecurityException) {
            // Fallback if exact alarm permission not granted
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                triggerTime,
                pendingIntent
            )
        }
    }
    
    fun rescheduleAllReminders(context: Context, tasks: List<Task>) {
        tasks.forEach { task ->
            if (task.deadline != null && 
                task.status != com.hiklass.taskmaster.data.model.TaskStatus.COMPLETED &&
                task.status != com.hiklass.taskmaster.data.model.TaskStatus.CANCELLED) {
                scheduleReminders(context, task.id, task)
            }
        }
    }
}

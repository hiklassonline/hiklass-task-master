package com.hiklass.taskmaster.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.hiklass.taskmaster.data.local.TaskDatabase
import com.hiklass.taskmaster.data.model.TaskStatus
import com.hiklass.taskmaster.util.ReminderManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_QUICKBOOT_POWERON) {
            
            // Reschedule all reminders after boot
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val database = TaskDatabase.getDatabase(context)
                    val taskDao = database.taskDao()
                    
                    // Get all active tasks with deadlines
                    val activeTasks = taskDao.getActiveTasks()
                    activeTasks.collect { tasks ->
                        val tasksWithDeadlines = tasks.filter { it.deadline != null }
                        ReminderManager.rescheduleAllReminders(context, tasksWithDeadlines)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }
}

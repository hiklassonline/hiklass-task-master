package com.hiklass.taskmaster.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters
import com.hiklass.taskmaster.data.local.Converters
import java.util.Date

@Entity(tableName = "tasks")
@TypeConverters(Converters::class)
data class Task(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    
    val title: String,
    val description: String = "",
    val deadline: Date? = null,
    val status: TaskStatus = TaskStatus.PENDING,
    val priority: TaskPriority = TaskPriority.MEDIUM,
    
    // Reminder settings
    val reminder2Days: Boolean = true,
    val reminder1Day: Boolean = true,
    val reminderOnDay: Boolean = true,
    
    // Sync status
    val isSynced: Boolean = false,
    val serverId: String? = null,
    val lastModified: Date = Date(),
    
    // Timestamps
    val createdAt: Date = Date(),
    val completedAt: Date? = null
)

enum class TaskStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED,
    CANCELLED
}

enum class TaskPriority {
    LOW,
    MEDIUM,
    HIGH,
    URGENT
}

// Extension functions
fun TaskPriority.getDisplayName(): String {
    return when (this) {
        TaskPriority.LOW -> "Low"
        TaskPriority.MEDIUM -> "Medium"
        TaskPriority.HIGH -> "High"
        TaskPriority.URGENT -> "Urgent"
    }
}

fun TaskPriority.getColorRes(): Int {
    return when (this) {
        TaskPriority.LOW -> com.hiklass.taskmaster.R.color.priority_low
        TaskPriority.MEDIUM -> com.hiklass.taskmaster.R.color.priority_medium
        TaskPriority.HIGH -> com.hiklass.taskmaster.R.color.priority_high
        TaskPriority.URGENT -> com.hiklass.taskmaster.R.color.priority_urgent
    }
}

fun TaskStatus.getDisplayName(): String {
    return when (this) {
        TaskStatus.PENDING -> "Pending"
        TaskStatus.IN_PROGRESS -> "In Progress"
        TaskStatus.COMPLETED -> "Completed"
        TaskStatus.CANCELLED -> "Cancelled"
    }
}

fun TaskStatus.getColorRes(): Int {
    return when (this) {
        TaskStatus.PENDING -> com.hiklass.taskmaster.R.color.status_pending
        TaskStatus.IN_PROGRESS -> com.hiklass.taskmaster.R.color.status_in_progress
        TaskStatus.COMPLETED -> com.hiklass.taskmaster.R.color.status_completed
        TaskStatus.CANCELLED -> com.hiklass.taskmaster.R.color.status_cancelled
    }
}

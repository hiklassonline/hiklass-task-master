package com.hiklass.taskmaster.data.remote

import com.hiklass.taskmaster.data.model.Task
import com.google.gson.annotations.SerializedName
import retrofit2.Response
import retrofit2.http.*

interface ApiService {
    
    @GET("api/tasks")
    suspend fun getAllTasks(): Response<List<TaskResponse>>
    
    @GET("api/tasks/{id}")
    suspend fun getTask(@Path("id") id: String): Response<TaskResponse>
    
    @POST("api/tasks")
    suspend fun createTask(@Body task: TaskSyncRequest): Response<TaskResponse>
    
    @PUT("api/tasks/{id}")
    suspend fun updateTask(
        @Path("id") id: String,
        @Body task: TaskSyncRequest
    ): Response<TaskResponse>
    
    @DELETE("api/tasks/{id}")
    suspend fun deleteTask(@Path("id") id: String): Response<Void>
    
    @POST("api/tasks/sync")
    suspend fun syncTasks(@Body tasks: List<TaskSyncRequest>): Response<SyncResponse>
    
    @GET("api/health")
    suspend fun checkHealth(): Response<HealthResponse>
}

data class TaskResponse(
    @SerializedName("id") val id: String,
    @SerializedName("localId") val localId: Long?,
    @SerializedName("title") val title: String,
    @SerializedName("description") val description: String?,
    @SerializedName("deadline") val deadline: Long?,
    @SerializedName("status") val status: String,
    @SerializedName("priority") val priority: String,
    @SerializedName("reminder2Days") val reminder2Days: Boolean,
    @SerializedName("reminder1Day") val reminder1Day: Boolean,
    @SerializedName("reminderOnDay") val reminderOnDay: Boolean,
    @SerializedName("createdAt") val createdAt: Long,
    @SerializedName("lastModified") val lastModified: Long
)

data class TaskSyncRequest(
    @SerializedName("localId") val localId: Long,
    @SerializedName("title") val title: String,
    @SerializedName("description") val description: String?,
    @SerializedName("deadline") val deadline: Long?,
    @SerializedName("status") val status: String,
    @SerializedName("priority") val priority: String,
    @SerializedName("reminder2Days") val reminder2Days: Boolean,
    @SerializedName("reminder1Day") val reminder1Day: Boolean,
    @SerializedName("reminderOnDay") val reminderOnDay: Boolean,
    @SerializedName("createdAt") val createdAt: Long,
    @SerializedName("lastModified") val lastModified: Long
)

data class SyncResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("message") val message: String,
    @SerializedName("syncedTasks") val syncedTasks: List<TaskResponse>,
    @SerializedName("failedCount") val failedCount: Int
)

data class HealthResponse(
    @SerializedName("status") val status: String,
    @SerializedName("version") val version: String
)

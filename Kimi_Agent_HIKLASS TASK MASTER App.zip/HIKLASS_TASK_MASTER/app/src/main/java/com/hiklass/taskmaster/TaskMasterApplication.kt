package com.hiklass.taskmaster

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.hiklass.taskmaster.util.NotificationHelper
import com.hiklass.taskmaster.worker.SyncWorker

class TaskMasterApplication : Application() {
    
    override fun onCreate() {
        super.onCreate()
        
        // Create notification channels
        NotificationHelper.createNotificationChannels(this)
        
        // Schedule periodic sync
        SyncWorker.schedule(this)
    }
}

package com.hiklass.taskmaster.worker

import android.content.Context
import androidx.work.*
import com.hiklass.taskmaster.data.local.TaskDatabase
import com.hiklass.taskmaster.data.repository.TaskRepository
import com.hiklass.taskmaster.util.NetworkUtils
import com.hiklass.taskmaster.util.NotificationHelper
import com.hiklass.taskmaster.util.PreferenceManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

class SyncWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {
    
    override suspend fun doWork(): Result {
        val context = applicationContext
        
        // Check if auto-sync is enabled
        val prefs = PreferenceManager(context)
        if (!prefs.isAutoSyncEnabled()) {
            return Result.success()
        }
        
        // Check network availability
        if (!NetworkUtils.isNetworkAvailable(context)) {
            return Result.retry()
        }
        
        return withContext(Dispatchers.IO) {
            try {
                val database = TaskDatabase.getDatabase(context)
                val repository = TaskRepository(database.taskDao(), context)
                
                val result = repository.syncTasks()
                
                if (result.success) {
                    prefs.setLastSyncTime(System.currentTimeMillis())
                    
                    // Show notification if there were failures
                    if (result.failedCount > 0) {
                        NotificationHelper.showSyncNotification(
                            context,
                            "${result.syncedCount} synced, ${result.failedCount} failed",
                            true
                        )
                    }
                    
                    Result.success()
                } else {
                    // Show error notification
                    NotificationHelper.showSyncNotification(
                        context,
                        result.message,
                        true
                    )
                    Result.retry()
                }
            } catch (e: Exception) {
                NotificationHelper.showSyncNotification(
                    context,
                    "Sync error: ${e.message}",
                    true
                )
                Result.retry()
            }
        }
    }
    
    companion object {
        private const val WORK_NAME = "sync_worker"
        private const val SYNC_INTERVAL_HOURS = 1L
        
        fun schedule(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .setRequiresBatteryNotLow(true)
                .build()
            
            val syncWorkRequest = PeriodicWorkRequestBuilder<SyncWorker>(
                SYNC_INTERVAL_HOURS,
                TimeUnit.HOURS
            )
                .setConstraints(constraints)
                .setBackoffCriteria(
                    BackoffPolicy.EXPONENTIAL,
                    WorkRequest.MIN_BACKOFF_MILLIS,
                    TimeUnit.MILLISECONDS
                )
                .build()
            
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                syncWorkRequest
            )
        }
        
        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }
        
        fun runImmediateSync(context: Context) {
            val syncWorkRequest = OneTimeWorkRequestBuilder<SyncWorker>()
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .build()
                )
                .build()
            
            WorkManager.getInstance(context).enqueue(syncWorkRequest)
        }
    }
}

package com.hiklass.taskmaster.data.remote

import android.content.Context
import com.hiklass.taskmaster.util.PreferenceManager
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object RetrofitClient {
    
    private const val DEFAULT_TIMEOUT = 30L
    
    fun createApiService(context: Context): ApiService? {
        val prefs = PreferenceManager(context)
        val serverUrl = prefs.getServerUrl()
        
        if (serverUrl.isNullOrBlank() || !prefs.isServerEnabled()) {
            return null
        }
        
        val baseUrl = if (serverUrl.endsWith("/")) serverUrl else "$serverUrl/"
        
        return createRetrofit(baseUrl, context)
    }
    
    fun createApiServiceWithUrl(serverUrl: String, context: Context): ApiService? {
        val baseUrl = if (serverUrl.endsWith("/")) serverUrl else "$serverUrl/"
        return createRetrofit(baseUrl, context)
    }
    
    private fun createRetrofit(baseUrl: String, context: Context): ApiService {
        val loggingInterceptor = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }
        
        val authInterceptor = Interceptor { chain ->
            val prefs = PreferenceManager(context)
            val apiKey = prefs.getApiKey()
            
            val requestBuilder = chain.request().newBuilder()
            
            apiKey?.let {
                requestBuilder.addHeader("Authorization", "Bearer $it")
            }
            
            requestBuilder.addHeader("Content-Type", "application/json")
            requestBuilder.addHeader("Accept", "application/json")
            
            chain.proceed(requestBuilder.build())
        }
        
        val client = OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)
            .addInterceptor(authInterceptor)
            .connectTimeout(DEFAULT_TIMEOUT, TimeUnit.SECONDS)
            .readTimeout(DEFAULT_TIMEOUT, TimeUnit.SECONDS)
            .writeTimeout(DEFAULT_TIMEOUT, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
        
        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
    
    fun testConnection(serverUrl: String, context: Context, callback: (Boolean, String) -> Unit) {
        val apiService = createApiServiceWithUrl(serverUrl, context)
        
        if (apiService == null) {
            callback(false, "Invalid server URL")
            return
        }
        
        kotlinx.coroutines.GlobalScope.launch {
            try {
                val response = apiService.checkHealth()
                if (response.isSuccessful) {
                    val health = response.body()
                    callback(true, health?.status ?: "Connected")
                } else {
                    callback(false, "Server error: ${response.code()}")
                }
            } catch (e: Exception) {
                callback(false, "Connection failed: ${e.message}")
            }
        }
    }
}

import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

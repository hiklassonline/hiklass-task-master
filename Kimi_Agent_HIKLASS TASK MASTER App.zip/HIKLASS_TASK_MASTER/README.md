# HIKLASS TASK MASTER

A powerful, reliable, and intelligent task management Android application designed to help individuals, professionals, and organizations create, manage, and track tasks efficiently — both offline and online.

## Features

- **Offline-First Task Management**: Create, edit, and manage tasks without internet access
- **Automatic Online Synchronization**: Syncs tasks when internet becomes available
- **Smart Deadline Reminders**: Notifications 2 days, 1 day, and on deadline day
- **Real-Time Notifications**: Reliable background notification system
- **Secure Local Storage**: Tasks safely stored on your device using Room database
- **Optional Server Integration**: Connect to a remote server for centralized management
- **Clean, Modern UI**: Material Design 3 interface optimized for productivity

## Technical Stack

- **Language**: Kotlin
- **Architecture**: MVVM with Repository pattern
- **Database**: Room (SQLite)
- **Background Work**: WorkManager
- **Networking**: Retrofit + OkHttp
- **UI**: Material Design 3 Components
- **Dependency Injection**: Manual (extensible to Hilt)

## Project Structure

```
app/src/main/java/com/hiklass/taskmaster/
├── data/
│   ├── local/          # Room database, DAOs, Converters
│   ├── model/          # Data classes (Task, ServerConfig, etc.)
│   ├── remote/         # Retrofit API service
│   └── repository/     # TaskRepository
├── receiver/           # BroadcastReceivers (Alarm, Boot)
├── service/            # Foreground services (Sync)
├── ui/
│   ├── main/           # MainActivity, TaskAdapter, MainViewModel
│   ├── settings/       # SettingsActivity
│   └── task/           # TaskDetailActivity, TaskDetailViewModel
├── util/               # Utility classes (NotificationHelper, ReminderManager, etc.)
├── worker/             # WorkManager workers (SyncWorker)
└── TaskMasterApplication.kt
```

## Building the App

### Prerequisites

- Android Studio Hedgehog (2023.1.1) or later
- JDK 17 or later
- Android SDK 34

### Build Steps

1. Open the project in Android Studio
2. Sync project with Gradle files
3. Build → Generate Signed Bundle/APK

### Create Keystore (First Time)

```bash
keytool -genkey -v -keystore hiklass-task-master.keystore -alias hiklass -keyalg RSA -keysize 2048 -validity 10000
```

### Build Signed APK

```bash
./gradlew assembleRelease
```

### Build Signed AAB (For Play Store)

```bash
./gradlew bundleRelease
```

## Play Store Upload

### Required Assets

Located in `playstore-assets/`:
- `feature-graphic.png` (1024x500)
- `playstore-icon.png` (512x512)
- `privacy-policy.html`
- `store-listing.txt`

### Screenshots Required

- Phone: 2-8 screenshots (16:9 or 9:16)
- 7-inch tablet: 2-8 screenshots
- 10-inch tablet: 2-8 screenshots

### Upload Steps

1. Build signed AAB: `./gradlew bundleRelease`
2. Go to Google Play Console
3. Create new app
4. Upload AAB to Production/Internal Testing
5. Fill store listing with content from `store-listing.txt`
6. Upload screenshots and feature graphic
7. Add privacy policy URL
8. Submit for review

## Configuration

### Server Settings

1. Go to Settings → Server Settings
2. Enable "Server Sync"
3. Enter your server URL (e.g., `https://api.yourserver.com`)
4. Optionally enter API key for authentication
5. Test connection

### API Endpoints Expected

```
GET    /api/health          - Health check
GET    /api/tasks           - Get all tasks
POST   /api/tasks           - Create task
PUT    /api/tasks/{id}      - Update task
DELETE /api/tasks/{id}      - Delete task
POST   /api/tasks/sync      - Bulk sync tasks
```

## Permissions

- `INTERNET` - For server synchronization
- `ACCESS_NETWORK_STATE` - To check network availability
- `POST_NOTIFICATIONS` - For task reminders
- `SCHEDULE_EXACT_ALARM` - For precise reminder alarms
- `RECEIVE_BOOT_COMPLETED` - To reschedule alarms after reboot
- `FOREGROUND_SERVICE` - For background sync service

## License

Copyright © 2026 HIKLASS Digital Agency. All rights reserved.

## Support

- Website: https://www.hiklass.online
- Email: support@hiklass.online

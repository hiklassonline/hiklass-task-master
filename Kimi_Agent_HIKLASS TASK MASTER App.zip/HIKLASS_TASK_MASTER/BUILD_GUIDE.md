# HIKLASS TASK MASTER - Build Guide

## 📦 Pre-built Files

This directory contains the complete Android project ready for building. Since Android SDK is required for compilation, below are instructions for building the APK and AAB files.

---

## 🚀 Quick Build Options

### Option 1: Android Studio (Recommended)

1. **Open Project**
   ```
   File → Open → Select HIKLASS_TASK_MASTER folder
   ```

2. **Sync Gradle**
   ```
   File → Sync Project with Gradle Files
   ```

3. **Build Signed Bundle/APK**
   ```
   Build → Generate Signed Bundle / APK...
   ```
   - Select "Android App Bundle" for AAB (Play Store)
   - Select "APK" for direct installation
   - Use keystore: `hiklass-task-master.keystore`
   - Keystore password: `hiklass123`
   - Key alias: `hiklass`
   - Key password: `hiklass123`

### Option 2: Command Line with Gradle

**Prerequisites:**
- Android SDK installed
- JAVA_HOME set to JDK 17+

```bash
cd HIKLASS_TASK_MASTER

# Create local.properties
echo "sdk.dir=/path/to/your/Android/Sdk" > local.properties

# Build signed APK
./gradlew assembleRelease

# Build signed AAB (for Play Store)
./gradlew bundleRelease
```

### Option 3: Docker Build (No Local Android SDK Needed)

```bash
# Run Android build in Docker
docker run --rm \
  -v "$(pwd):/project" \
  -w /project \
  mingc/android-build-box \
  bash -c "
    echo 'sdk.dir=/opt/android-sdk' > local.properties &&
    ./gradlew assembleRelease bundleRelease
  "
```

---

## 📋 Build Outputs

After successful build, files will be located at:

| File Type | Location |
|-----------|----------|
| Signed APK | `app/build/outputs/apk/release/app-release.apk` |
| Signed AAB | `app/build/outputs/bundle/release/app-release.aab` |

---

## 🔐 Signing Information

| Property | Value |
|----------|-------|
| Keystore File | `hiklass-task-master.keystore` |
| Keystore Password | `hiklass123` |
| Key Alias | `hiklass` |
| Key Password | `hiklass123` |

**⚠️ IMPORTANT:** Keep the keystore file secure. Losing it means you cannot update the app on Play Store.

---

## 📱 App Information

| Property | Value |
|----------|-------|
| App Name | HIKLASS TASK MASTER |
| Package | `com.hiklass.taskmaster` |
| Version Code | 1 |
| Version Name | 1.0.0 |
| Min SDK | 24 (Android 7.0) |
| Target SDK | 34 (Android 14) |

---

## 🌐 Play Store Upload

### Required Files

1. **Signed AAB**: `app-release.aab`
2. **Feature Graphic**: `playstore-assets/feature-graphic.png`
3. **App Icon**: `playstore-assets/playstore-icon.png`
4. **Privacy Policy**: `playstore-assets/privacy-policy.html`
5. **Store Listing**: See `playstore-assets/store-listing.txt`

### Upload Steps

1. Go to [Google Play Console](https://play.google.com/console)
2. Click "Create app"
3. Enter app name: "HIKLASS TASK MASTER"
4. Upload the AAB file
5. Fill store listing with content from `store-listing.txt`
6. Upload screenshots (phone, tablet)
7. Upload feature graphic and app icon
8. Add privacy policy URL
9. Set content rating to "Everyone"
10. Submit for review

---

## 🛠️ Troubleshooting

### Build Fails with "SDK not found"
```bash
# Create local.properties with your SDK path
echo "sdk.dir=/Users/YOUR_NAME/Library/Android/sdk" > local.properties  # macOS
echo "sdk.dir=C:\\Users\\YOUR_NAME\\AppData\\Local\\Android\\Sdk" > local.properties  # Windows
echo "sdk.dir=/home/YOUR_NAME/Android/Sdk" > local.properties  # Linux
```

### Gradle Sync Issues
```bash
# Clean and rebuild
./gradlew clean
./gradlew build
```

### Out of Memory Error
```bash
# Increase Gradle heap size
export GRADLE_OPTS="-Xmx4g -XX:MaxMetaspaceSize=512m"
./gradlew assembleRelease
```

---

## 📞 Support

**Developer:** HIKLASS Digital Agency  
**Website:** https://www.hiklass.online  
**Email:** support@hiklass.online

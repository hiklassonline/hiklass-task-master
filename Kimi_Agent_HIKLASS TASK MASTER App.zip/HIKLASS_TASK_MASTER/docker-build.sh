#!/bin/bash

# HIKLASS TASK MASTER - Docker Build Script
# This script builds the app using a Docker container with Android SDK

echo "═══════════════════════════════════════════════════════════════"
echo "     HIKLASS TASK MASTER - Docker Build"
echo "═══════════════════════════════════════════════════════════════"
echo ""

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed. Please install Docker first."
    echo "   Visit: https://docs.docker.com/get-docker/"
    exit 1
fi

echo "🐳 Pulling Android build image..."
docker pull mingc/android-build-box:latest

echo ""
echo "🔨 Building HIKLASS TASK MASTER..."
echo ""

# Run build in Docker
docker run --rm \
  -v "$(pwd):/project" \
  -w /project \
  mingc/android-build-box:latest \
  bash -c "
    echo 'sdk.dir=/opt/android-sdk' > local.properties
    echo 'Building signed APK...'
    ./gradlew assembleRelease --no-daemon
    echo 'Building signed AAB...'
    ./gradlew bundleRelease --no-daemon
  "

BUILD_STATUS=$?

echo ""
if [ $BUILD_STATUS -eq 0 ]; then
    echo "═══════════════════════════════════════════════════════════════"
    echo "                    ✅ BUILD SUCCESSFUL"
    echo "═══════════════════════════════════════════════════════════════"
    echo ""
    echo "📱 Signed APK:"
    echo "   app/build/outputs/apk/release/app-release.apk"
    echo ""
    echo "📦 Play Store Bundle (AAB):"
    echo "   app/build/outputs/bundle/release/app-release.aab"
    echo ""
    echo "🚀 Ready for Play Store upload!"
    echo ""
else
    echo "═══════════════════════════════════════════════════════════════"
    echo "                    ❌ BUILD FAILED"
    echo "═══════════════════════════════════════════════════════════════"
    echo ""
    echo "Check the error messages above for details."
    exit 1
fi

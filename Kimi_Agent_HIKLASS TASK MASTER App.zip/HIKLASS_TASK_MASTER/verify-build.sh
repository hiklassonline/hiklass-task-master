#!/bin/bash

echo "═══════════════════════════════════════════════════════════════"
echo "        HIKLASS TASK MASTER - Build Verification"
echo "═══════════════════════════════════════════════════════════════"
echo ""

# Check Java
echo "Checking Java..."
if command -v java &> /dev/null; then
    JAVA_VERSION=$(java -version 2>&1 | awk -F '"' '/version/ {print $2}')
    echo "  ✓ Java found: $JAVA_VERSION"
else
    echo "  ✗ Java not found - Please install JDK 17 or higher"
    exit 1
fi

# Check Android SDK
echo ""
echo "Checking Android SDK..."
if [ -n "$ANDROID_SDK_ROOT" ] || [ -n "$ANDROID_HOME" ]; then
    SDK_PATH="${ANDROID_SDK_ROOT:-$ANDROID_HOME}"
    echo "  ✓ Android SDK found: $SDK_PATH"
else
    echo "  ✗ Android SDK not found"
    echo "    Set ANDROID_SDK_ROOT environment variable"
fi

# Check local.properties
echo ""
echo "Checking local.properties..."
if [ -f "local.properties" ]; then
    echo "  ✓ local.properties exists"
    cat local.properties
else
    echo "  ✗ local.properties not found"
    echo "    Create it with: echo 'sdk.dir=/path/to/Android/Sdk' > local.properties"
fi

# Check keystore
echo ""
echo "Checking keystore..."
if [ -f "hiklass-task-master.keystore" ]; then
    echo "  ✓ Keystore found"
    keytool -list -v -keystore hiklass-task-master.keystore -storepass hiklass123 2>&1 | grep -E "Alias|Creation" | head -3
else
    echo "  ✗ Keystore not found"
fi

# Check current APK
echo ""
echo "Checking current APK..."
if [ -f "app/build/outputs/apk/release/app-release.apk" ]; then
    APK_SIZE=$(stat -f%z "app/build/outputs/apk/release/app-release.apk" 2>/dev/null || stat -c%s "app/build/outputs/apk/release/app-release.apk" 2>/dev/null)
    echo "  APK size: $APK_SIZE bytes"
    if [ "$APK_SIZE" -lt 10000 ]; then
        echo "  ⚠ WARNING: This is a PLACEHOLDER APK - You need to build the real one!"
    else
        echo "  ✓ This looks like a real APK"
    fi
else
    echo "  ✗ APK not found"
fi

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "To build the real APK, run:"
echo "  ./gradlew assembleRelease"
echo "═══════════════════════════════════════════════════════════════"
